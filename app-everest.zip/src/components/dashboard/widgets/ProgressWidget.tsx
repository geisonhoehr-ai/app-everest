import { ProgressOverview } from '@/components/dashboard/ProgressOverview'

export const ProgressWidget = () => {
  return <ProgressOverview />
}
