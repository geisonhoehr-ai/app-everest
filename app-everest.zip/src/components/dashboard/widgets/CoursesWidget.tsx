import { MyCourses } from '@/components/dashboard/MyCourses'

export const CoursesWidget = () => {
  return <MyCourses />
}
