import { WelcomeBanner } from '@/components/dashboard/WelcomeBanner'

export const WelcomeWidget = () => {
  return <WelcomeBanner />
}
