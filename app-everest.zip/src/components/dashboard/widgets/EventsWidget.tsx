import { UpcomingEvents } from '@/components/dashboard/UpcomingEvents'

export const EventsWidget = () => {
  return <UpcomingEvents />
}
