import { Skeleton } from '@/components/ui/skeleton'

export const SectionLoader = () => (
  <div className="bg-background">
    <div className="container py-16 md:py-24">
      <div className="flex flex-col items-center space-y-6">
        <Skeleton className="h-8 w-1/2 rounded-md" />
        <Skeleton className="h-6 w-3/4 rounded-md" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full pt-8">
          <div className="flex flex-col space-y-3">
            <Skeleton className="h-48 w-full rounded-lg" />
            <Skeleton className="h-6 w-3/4 rounded-md" />
            <Skeleton className="h-4 w-1/2 rounded-md" />
          </div>
          <div className="flex flex-col space-y-3">
            <Skeleton className="h-48 w-full rounded-lg" />
            <Skeleton className="h-6 w-3/4 rounded-md" />
            <Skeleton className="h-4 w-1/2 rounded-md" />
          </div>
          <div className="flex flex-col space-y-3">
            <Skeleton className="h-48 w-full rounded-lg" />
            <Skeleton className="h-6 w-3/4 rounded-md" />
            <Skeleton className="h-4 w-1/2 rounded-md" />
          </div>
        </div>
      </div>
    </div>
  </div>
)
