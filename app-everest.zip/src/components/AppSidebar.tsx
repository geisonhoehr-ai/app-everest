import { Link, useLocation, useNavigate } from 'react-router-dom'
import {
  BookOpen,
  Calendar,
  ClipboardCheck,
  FileText,
  HelpCircle,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  Mountain,
  Settings,
  TrendingUp,
  Layers,
  ListChecks,
  Radio,
  Archive,
  Users,
} from 'lucide-react'

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarSeparator,
} from '@/components/ui/sidebar'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { cn } from '@/lib/utils'
import { useAuth } from '@/contexts/auth-provider'

const menuItems = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/meus-cursos', label: 'Meus Cursos', icon: BookOpen },
  { href: '/calendario', label: 'Calendário', icon: Calendar },
  { href: '/flashcards', label: 'Flashcards', icon: Layers },
  { href: '/meus-conjuntos', label: 'Meus Conjuntos', icon: Users },
  { href: '/quizzes', label: 'Quizzes', icon: ListChecks },
  { href: '/evercast', label: 'Evercast', icon: Radio },
  { href: '/redacoes', label: 'Redações', icon: FileText },
  { href: '/simulados', label: 'Simulados', icon: ClipboardCheck },
  { href: '/banco-de-questoes', label: 'Questões', icon: Archive },
  { href: '/progresso', label: 'Progresso', icon: TrendingUp },
  { href: '/forum', label: 'Fórum', icon: MessageSquare },
]

const bottomMenuItems = [
  { href: '/configuracoes', label: 'Configurações', icon: Settings },
  { href: '/faq', label: 'Ajuda', icon: HelpCircle },
]

export const AppSidebar = () => {
  const location = useLocation()
  const navigate = useNavigate()
  const { profile, signOut } = useAuth()

  const handleSignOut = async () => {
    await signOut()
    navigate('/login')
  }

  const isActive = (path: string) => {
    if (path === '/dashboard') {
      return location.pathname === '/dashboard'
    }
    return location.pathname.startsWith(path)
  }

  const getInitials = () => {
    if (!profile) return 'U'
    const first = profile.first_name?.charAt(0) || ''
    const last = profile.last_name?.charAt(0) || ''
    return `${first}${last}`.toUpperCase()
  }

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <div className="flex items-center gap-2">
          <Mountain className="h-6 w-6 text-primary" />
          <span className="font-bold text-lg">Everest</span>
        </div>
      </SidebarHeader>
      <SidebarContent className="flex-grow">
        <SidebarMenu>
          {menuItems.map((item) => (
            <SidebarMenuItem key={item.label}>
              <SidebarMenuButton asChild isActive={isActive(item.href)}>
                <Link to={item.href}>
                  <item.icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="flex flex-col gap-4">
        <SidebarMenu>
          {bottomMenuItems.map((item) => (
            <SidebarMenuItem key={item.label}>
              <SidebarMenuButton asChild isActive={isActive(item.href)}>
                <Link to={item.href}>
                  <item.icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
          <SidebarSeparator />
          <SidebarMenuItem>
            <SidebarMenuButton onClick={handleSignOut}>
              <LogOut className="h-5 w-5" />
              <span>Sair</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
        <div
          className={cn(
            'flex items-center gap-3 rounded-lg p-2 transition-colors',
            'bg-muted text-muted-foreground',
          )}
        >
          <Avatar className="h-9 w-9">
            <AvatarImage
              src={`https://img.usecurling.com/ppl/medium?seed=${profile?.id}`}
              alt="Avatar"
            />
            <AvatarFallback>{getInitials()}</AvatarFallback>
          </Avatar>
          <div className="flex flex-col overflow-hidden">
            <span className="text-sm font-semibold text-foreground truncate">
              {profile?.first_name} {profile?.last_name}
            </span>
            <span className="text-xs text-muted-foreground truncate">
              {profile?.email}
            </span>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
