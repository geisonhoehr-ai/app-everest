import {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from 'react'
import { User, Session } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabase/client'
import { getUserProfile, type UserProfile } from '@/services/userService'
import { useToast } from '@/hooks/use-toast'

interface AuthContextType {
  user: User | null
  session: Session | null
  profile: UserProfile | null
  signIn: (email: string, password: string) => Promise<{ error: any }>
  signOut: () => Promise<{ error: any }>
  loading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchSessionAndProfile = async (currentSession: Session | null) => {
      if (currentSession?.user) {
        try {
          const userProfile = await getUserProfile(currentSession.user.id)
          if (userProfile) {
            setProfile(userProfile)
          } else {
            toast({
              title: 'Erro de Perfil',
              description:
                'Não foi possível encontrar seu perfil. Por favor, contate o suporte.',
              variant: 'destructive',
            })
            await supabase.auth.signOut()
            setProfile(null)
          }
        } catch (error) {
          console.error('Error fetching profile:', error)
          toast({ title: 'Erro ao carregar perfil', variant: 'destructive' })
          await supabase.auth.signOut()
          setProfile(null)
        }
      } else {
        setProfile(null)
      }
    }

    const initializeAuth = async () => {
      const {
        data: { session: initialSession },
      } = await supabase.auth.getSession()
      setSession(initialSession)
      await fetchSessionAndProfile(initialSession)
      setLoading(false)
    }

    initializeAuth()

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (_event, newSession) => {
      setSession(newSession)
      await fetchSessionAndProfile(newSession)
    })

    return () => subscription.unsubscribe()
  }, [toast])

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })
    return { error }
  }

  const signOut = async () => {
    const { error } = await supabase.auth.signOut()
    setProfile(null)
    return { error }
  }

  const value = {
    user: session?.user ?? null,
    session,
    profile,
    signIn,
    signOut,
    loading,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
