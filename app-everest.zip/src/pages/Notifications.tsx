import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { BookOpen, FileText, ListChecks } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Link } from 'react-router-dom'

const mockNotifications = [
  {
    id: 1,
    type: 'new_lesson',
    title: 'Nova aula disponível!',
    message: 'A aula "Frações e Decimais" foi adicionada ao módulo 1.',
    related_entity_id: 'licao-102',
    is_read: false,
    created_at: '2 horas atrás',
  },
  {
    id: 2,
    type: 'new_material',
    title: 'Novo material de apoio',
    message: 'Um PDF de resumo foi adicionado à aula de Aritmética.',
    related_entity_id: 'licao-101',
    is_read: false,
    created_at: '1 dia atrás',
  },
  {
    id: 3,
    type: 'quiz_available',
    title: 'Quiz liberado',
    message: 'O quiz do Módulo 1 já está disponível para você testar.',
    related_entity_id: 'quiz-1',
    is_read: true,
    created_at: '3 dias atrás',
  },
]

const notificationIcons = {
  new_lesson: <BookOpen className="h-5 w-5 text-blue-500" />,
  new_material: <FileText className="h-5 w-5 text-green-500" />,
  quiz_available: <ListChecks className="h-5 w-5 text-purple-500" />,
}

export default function NotificationsPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Notificações</CardTitle>
        <CardDescription>
          Fique por dentro de todas as novidades da plataforma.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {mockNotifications.map((notification) => (
            <Link
              to="#"
              key={notification.id}
              className={cn(
                'block p-4 border rounded-lg transition-colors',
                notification.is_read
                  ? 'bg-card text-muted-foreground'
                  : 'bg-muted/50 hover:bg-muted',
              )}
            >
              <div className="flex items-start gap-4">
                <div className="mt-1">
                  {
                    notificationIcons[
                      notification.type as keyof typeof notificationIcons
                    ]
                  }
                </div>
                <div className="flex-grow">
                  <p
                    className={cn(
                      'font-semibold',
                      !notification.is_read && 'text-foreground',
                    )}
                  >
                    {notification.title}
                  </p>
                  <p className="text-sm">{notification.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {notification.created_at}
                  </p>
                </div>
                {!notification.is_read && (
                  <div className="w-2.5 h-2.5 bg-primary rounded-full mt-2" />
                )}
              </div>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
