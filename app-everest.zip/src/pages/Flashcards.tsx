import { Link } from 'react-router-dom'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { useEffect, useState } from 'react'
import {
  getSubjects,
  type SubjectWithTopicCount,
} from '@/services/subjectService'
import { SectionLoader } from '@/components/SectionLoader'

const groupBy = <T, K extends keyof any>(list: T[], getKey: (item: T) => K) =>
  list.reduce(
    (previous, currentItem) => {
      const group = getKey(currentItem)
      if (!previous[group]) previous[group] = []
      previous[group].push(currentItem)
      return previous
    },
    {} as Record<K, T[]>,
  )

export default function FlashcardsPage() {
  const [subjects, setSubjects] = useState<SubjectWithTopicCount[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    getSubjects()
      .then(setSubjects)
      .catch(console.error)
      .finally(() => setIsLoading(false))
  }, [])

  if (isLoading) {
    return <SectionLoader />
  }

  const groupedSubjects = groupBy(
    subjects,
    (subject) => subject.category || 'Outros',
  )

  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Flashcards</CardTitle>
          <CardDescription>
            Selecione uma matéria para começar a revisar.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          {Object.entries(groupedSubjects).map(([category, subjectList]) => (
            <div key={category}>
              <h2 className="text-2xl font-semibold tracking-tight mb-4">
                {category}
              </h2>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {subjectList.map((subject) => (
                  <Link to={`/flashcards/${subject.id}`} key={subject.id}>
                    <Card className="rounded-2xl border transition-all duration-200 min-h-[280px] hover:shadow-xl hover:-translate-y-2 hover:scale-102 cursor-pointer overflow-hidden flex flex-col h-full">
                      <img
                        src={
                          subject.image_url ||
                          `https://img.usecurling.com/p/400/200?q=${encodeURIComponent(
                            subject.name,
                          )}`
                        }
                        alt={subject.name}
                        className="w-full h-32 object-cover"
                      />
                      <div className="p-6 flex flex-col flex-grow">
                        <h3 className="font-semibold text-lg flex-grow">
                          {subject.name}
                        </h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {subject.description}
                        </p>
                      </div>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
