import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { FilePlus2, Eye, FileDown } from 'lucide-react'

const essays = [
  {
    id: 1,
    theme: 'Inteligência Artificial e o Futuro do Trabalho',
    date: '20/10/2025',
    status: 'Corrigida',
    grade: 920,
  },
  {
    id: 2,
    theme: 'A Persistência da Violência Contra a Mulher na Sociedade',
    date: '05/10/2025',
    status: 'Corrigida',
    grade: 880,
  },
  {
    id: 3,
    theme: 'Desafios da Educação a Distância no Brasil',
    date: '28/09/2025',
    status: 'Enviada',
    grade: null,
  },
]

export default function EssaysPage() {
  return (
    <Card>
      <CardHeader className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <CardTitle>Minhas Redações</CardTitle>
          <CardDescription>
            Envie suas redações e acompanhe suas correções e notas.
          </CardDescription>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link to="/redacoes/evolucao" target="_blank">
              <FileDown className="mr-2 h-4 w-4" />
              Exportar Evolução
            </Link>
          </Button>
          <Button asChild>
            <Link to="/redacoes/nova">
              <FilePlus2 className="mr-2 h-4 w-4" />
              Enviar Nova Redação
            </Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Tema</TableHead>
              <TableHead className="hidden md:table-cell">
                Data de Envio
              </TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Nota</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {essays.map((essay) => (
              <TableRow key={essay.theme}>
                <TableCell className="font-medium">{essay.theme}</TableCell>
                <TableCell className="hidden md:table-cell">
                  {essay.date}
                </TableCell>
                <TableCell>
                  <Badge
                    variant={
                      essay.status === 'Corrigida' ? 'default' : 'secondary'
                    }
                    className={
                      essay.status === 'Corrigida'
                        ? 'bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-400'
                        : ''
                    }
                  >
                    {essay.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right font-semibold">
                  {essay.grade ?? '-'}
                </TableCell>
                <TableCell className="text-right">
                  {essay.status === 'Corrigida' && (
                    <Button variant="outline" size="icon" asChild>
                      <Link to={`/redacoes/${essay.id}`}>
                        <Eye className="h-4 w-4" />
                      </Link>
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}
