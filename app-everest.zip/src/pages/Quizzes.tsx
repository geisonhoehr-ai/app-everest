import { Link } from 'react-router-dom'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { quizData } from '@/lib/data'

export default function QuizzesPage() {
  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Quizzes</CardTitle>
          <CardDescription>
            Selecione uma matéria para testar seus conhecimentos.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {quizData.map((subject) => (
            <Link to={`/quizzes/${subject.id}`} key={subject.id}>
              <Card className="rounded-2xl border transition-all duration-200 min-h-[280px] hover:shadow-xl hover:-translate-y-2 hover:scale-102 cursor-pointer overflow-hidden flex flex-col h-full">
                <img
                  src={subject.image}
                  alt={subject.name}
                  className="w-full h-32 object-cover"
                />
                <div className="p-6 flex flex-col flex-grow">
                  <h3 className="font-semibold text-lg flex-grow">
                    {subject.name}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {subject.description}
                  </p>
                </div>
              </Card>
            </Link>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
