import { useState, useEffect, useRef } from 'react'
import { useAuth } from '@/contexts/auth-provider'
import {
  getUserSettings,
  saveDashboardLayout,
} from '@/services/userSettingsService'
import { DEFAULT_LAYOUTS, AVAILABLE_WIDGETS } from '@/lib/dashboard-config'
import { WidgetRenderer } from '@/components/dashboard/WidgetRenderer'
import { CustomizationPanel } from '@/components/dashboard/CustomizationPanel'
import { Button } from '@/components/ui/button'
import { Settings } from 'lucide-react'
import { SectionLoader } from '@/components/SectionLoader'
import { useToast } from '@/components/ui/use-toast'
import { cn } from '@/lib/utils'

export default function DashboardPage() {
  const { user, profile } = useAuth()
  const { toast } = useToast()
  const [layout, setLayout] = useState<{ order: string[]; hidden: string[] }>({
    order: [],
    hidden: [],
  })
  const [isLoading, setIsLoading] = useState(true)
  const [isCustomizing, setIsCustomizing] = useState(false)

  const draggedItemIndex = useRef<number | null>(null)
  const dragOverItemIndex = useRef<number | null>(null)
  const [dragOverVisualIndex, setDragOverVisualIndex] = useState<number | null>(
    null,
  )

  useEffect(() => {
    if (user && profile) {
      setIsLoading(true)
      getUserSettings(user.id)
        .then((settings) => {
          const savedLayout = settings?.dashboard_layout as any
          if (savedLayout && savedLayout.order) {
            setLayout(savedLayout)
          } else {
            setLayout(DEFAULT_LAYOUTS[profile.role])
          }
        })
        .finally(() => setIsLoading(false))
    }
  }, [user, profile])

  if (isLoading || !profile) {
    return <SectionLoader />
  }

  const handleSave = async () => {
    if (!user) return
    await saveDashboardLayout(user.id, layout)
    toast({ title: 'Dashboard salvo com sucesso!' })
    setIsCustomizing(false)
  }

  const handleReset = () => {
    setLayout(DEFAULT_LAYOUTS[profile.role])
    toast({ title: 'Dashboard restaurado para o padrão.' })
  }

  const handleVisibilityChange = (widgetId: string, isVisible: boolean) => {
    setLayout((prev) => {
      const newOrder = isVisible
        ? [...prev.order, widgetId]
        : prev.order.filter((id) => id !== widgetId)
      const newHidden = isVisible
        ? prev.hidden.filter((id) => id !== widgetId)
        : [...prev.hidden, widgetId]
      return { order: newOrder, hidden: newHidden }
    })
  }

  const handleDragStart = (index: number) => {
    draggedItemIndex.current = index
  }

  const handleDragEnter = (index: number) => {
    dragOverItemIndex.current = index
    setDragOverVisualIndex(index)
  }

  const handleDrop = () => {
    if (
      draggedItemIndex.current === null ||
      dragOverItemIndex.current === null ||
      draggedItemIndex.current === dragOverItemIndex.current
    ) {
      return
    }
    const newOrder = [...layout.order]
    const [draggedItem] = newOrder.splice(draggedItemIndex.current, 1)
    newOrder.splice(dragOverItemIndex.current, 0, draggedItem)
    setLayout({ ...layout, order: newOrder })
  }

  const handleDragEnd = () => {
    draggedItemIndex.current = null
    dragOverItemIndex.current = null
    setDragOverVisualIndex(null)
  }

  return (
    <>
      <CustomizationPanel
        isOpen={isCustomizing}
        onOpenChange={setIsCustomizing}
        visibleWidgets={layout.order}
        onVisibilityChange={handleVisibilityChange}
        onSave={handleSave}
        onReset={handleReset}
        userRole={profile.role}
      />
      <div className="flex flex-col gap-6">
        <div className="flex justify-end">
          <Button variant="outline" onClick={() => setIsCustomizing(true)}>
            <Settings className="mr-2 h-4 w-4" />
            Personalizar
          </Button>
        </div>
        <div className="space-y-6">
          {layout.order
            .filter((id) => AVAILABLE_WIDGETS[profile.role].includes(id))
            .map((widgetId, index) => (
              <div
                key={widgetId}
                draggable
                onDragStart={() => handleDragStart(index)}
                onDragEnter={() => handleDragEnter(index)}
                onDragEnd={handleDragEnd}
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleDrop}
                className={cn(
                  'cursor-move transition-all rounded-lg',
                  dragOverVisualIndex === index && 'bg-primary/10',
                )}
              >
                <WidgetRenderer widgetId={widgetId} />
              </div>
            ))}
        </div>
      </div>
    </>
  )
}
