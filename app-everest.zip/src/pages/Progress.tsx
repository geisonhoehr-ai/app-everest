import {
  Bar,
  BarChart,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
} from 'recharts'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart'
import { Button } from '@/components/ui/button'
import { Link } from 'react-router-dom'
import { History } from 'lucide-react'

const weeklyHoursData = [
  { date: '24/06', hours: 2.5 },
  { date: '25/06', hours: 3 },
  { date: '26/06', hours: 4 },
  { date: '27/06', hours: 2 },
  { date: '28/06', hours: 5 },
  { date: '29/06', hours: 6 },
  { date: '30/06', hours: 1.5 },
]

const subjectPerformanceData = [
  { subject: 'Matemática', performance: 85, color: 'hsl(var(--chart-1))' },
  { subject: 'Português', performance: 92, color: 'hsl(var(--chart-2))' },
  { subject: 'História', performance: 78, color: 'hsl(var(--chart-3))' },
  { subject: 'Física', performance: 70, color: 'hsl(var(--chart-4))' },
  { subject: 'Química', performance: 81, color: 'hsl(var(--chart-5))' },
]

export default function ProgressPage() {
  return (
    <div className="grid gap-6 sm:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
      <Card className="xl:col-span-3">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Visão Geral do Progresso</CardTitle>
            <CardDescription>
              Acompanhe sua evolução nos estudos.
            </CardDescription>
          </div>
          <Button asChild variant="outline">
            <Link to="/progresso/historico-flashcards">
              <History className="mr-2 h-4 w-4" />
              Histórico de Flashcards
            </Link>
          </Button>
        </CardHeader>
      </Card>
      <Card className="xl:col-span-2">
        <CardHeader>
          <CardTitle>Horas de Estudo</CardTitle>
          <CardDescription>Sua dedicação nos últimos 7 dias.</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={{}} className="h-64 w-full">
            <LineChart data={weeklyHoursData}>
              <ChartTooltip content={<ChartTooltipContent />} />
              <Line
                type="monotone"
                dataKey="hours"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
              />
            </LineChart>
          </ChartContainer>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Desempenho por Matéria</CardTitle>
          <CardDescription>
            Percentual de acertos nos simulados.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={{}} className="h-64 w-full">
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={subjectPerformanceData}
                  dataKey="performance"
                  nameKey="subject"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="hsl(var(--primary))"
                  label
                />
                <ChartTooltip content={<ChartTooltipContent />} />
              </PieChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>
      <Card className="xl:col-span-3">
        <CardHeader>
          <CardTitle>Visão Geral do Desempenho</CardTitle>
          <CardDescription>Comparativo de acertos por matéria.</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={{}} className="h-80 w-full">
            <BarChart data={subjectPerformanceData} layout="vertical">
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="performance" layout="vertical" radius={4} />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  )
}
