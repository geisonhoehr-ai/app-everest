import { Link, useParams, useNavigate } from 'react-router-dom'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ArrowLeft, ListChecks, Play } from 'lucide-react'
import { quizData } from '@/lib/data'
import { Badge } from '@/components/ui/badge'

export default function QuizTopicsPage() {
  const { subjectId } = useParams<{ subjectId: string }>()
  const navigate = useNavigate()
  const subject = quizData.find((s) => s.id === subjectId)

  if (!subject) {
    return (
      <div className="text-center">
        <h2 className="text-2xl font-bold">Matéria não encontrada</h2>
        <Button onClick={() => navigate('/quizzes')} className="mt-4">
          Voltar para Matérias
        </Button>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" asChild>
          <Link to="/quizzes">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold">{subject.name}</h1>
          <p className="text-muted-foreground">
            Selecione um quiz para testar seus conhecimentos.
          </p>
        </div>
      </div>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {subject.topics.map((topic) => (
          <Card
            key={topic.id}
            className="rounded-2xl p-6 border transition-all duration-200 min-h-[280px] flex flex-col hover:shadow-xl hover:-translate-y-2 hover:scale-102 cursor-pointer"
          >
            <CardHeader className="p-0">
              <CardTitle>{topic.title}</CardTitle>
              <CardDescription>
                <Badge
                  variant="outline"
                  className="flex items-center gap-2 w-fit mt-2"
                >
                  <ListChecks className="h-4 w-4" />
                  {topic.questionCount} questões
                </Badge>
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0 flex-grow flex items-end mt-4">
              <Button asChild className="w-full">
                <Link to={`/quizzes/${subjectId}/${topic.id}`}>
                  <Play className="mr-2 h-4 w-4" /> Iniciar Quiz
                </Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
