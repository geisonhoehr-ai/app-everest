import { Button } from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Input } from '@/components/ui/input'
import { Search } from 'lucide-react'
import { Link } from 'react-router-dom'

const allCourses = [
  {
    id: 'matematica-para-concursos',
    title: 'Matemática para Concursos',
    category: 'Exatas',
    progress: 75,
    image: 'https://img.usecurling.com/p/400/200?q=mathematics%20abstract',
  },
  {
    id: 'redacao-nota-mil',
    title: 'Redação Nota Mil',
    category: 'Linguagens',
    progress: 40,
    image: 'https://img.usecurling.com/p/400/200?q=writing%20on%20paper',
  },
  {
    id: 'historia-do-brasil',
    title: 'História do Brasil',
    category: 'Humanas',
    progress: 90,
    image: 'https://img.usecurling.com/p/400/200?q=brazil%20colonial%20history',
  },
  {
    id: 'fisica-moderna',
    title: 'Física Moderna',
    category: 'Exatas',
    progress: 25,
    image: 'https://img.usecurling.com/p/400/200?q=physics%20quantum',
  },
  {
    id: 'literatura-brasileira',
    title: 'Literatura Brasileira',
    category: 'Linguagens',
    progress: 60,
    image:
      'https://img.usecurling.com/p/400/200?q=brazilian%20literature%20books',
  },
  {
    id: 'geografia-mundial',
    title: 'Geografia Mundial',
    category: 'Humanas',
    progress: 10,
    image: 'https://img.usecurling.com/p/400/200?q=world%20map',
  },
]

export default function CoursesPage() {
  return (
    <div className="flex flex-col gap-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle>Meus Cursos</CardTitle>
              <CardDescription>
                Todos os seus cursos em um só lugar. Continue sua jornada!
              </CardDescription>
            </div>
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Buscar em meus cursos..."
                className="pl-8 w-full md:w-64"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {allCourses.map((course) => (
            <Card
              key={course.title}
              className="rounded-2xl border transition-all duration-200 hover:shadow-xl hover:-translate-y-2 hover:scale-102 cursor-pointer overflow-hidden flex flex-col"
            >
              <Link
                to={`/meus-cursos/${course.id}`}
                className="flex flex-col h-full"
              >
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-full h-32 object-cover"
                />
                <div className="p-6 flex flex-col flex-grow">
                  <p className="text-xs text-primary font-semibold mb-1">
                    {course.category}
                  </p>
                  <h3 className="font-semibold text-md flex-grow">
                    {course.title}
                  </h3>
                  <div className="flex items-center gap-3 my-4">
                    <Progress value={course.progress} className="w-full" />
                    <span className="text-sm font-medium">
                      {course.progress}%
                    </span>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full mt-auto"
                  >
                    Acessar Curso
                  </Button>
                </div>
              </Link>
            </Card>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
