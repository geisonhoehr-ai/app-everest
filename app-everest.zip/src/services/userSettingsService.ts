import { supabase } from '@/lib/supabase/client'
import type { Database, Json } from '@/lib/supabase/types'

export type UserSettings = Database['public']['Tables']['user_settings']['Row']

export const getUserSettings = async (
  userId: string,
): Promise<UserSettings | null> => {
  const { data, error } = await supabase
    .from('user_settings')
    .select('*')
    .eq('user_id', userId)
    .single()

  if (error && error.code !== 'PGRST116') {
    // PGRST116: no rows found, which is not an error here
    console.error('Error fetching user settings:', error)
    throw error
  }

  return data
}

export const saveDashboardLayout = async (
  userId: string,
  layout: Json,
): Promise<UserSettings | null> => {
  const { data, error } = await supabase
    .from('user_settings')
    .upsert(
      { user_id: userId, dashboard_layout: layout },
      { onConflict: 'user_id' },
    )
    .select()
    .single()

  if (error) {
    console.error('Error saving dashboard layout:', error)
    throw error
  }

  return data
}
